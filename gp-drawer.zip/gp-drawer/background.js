// 1) Підставляє панель у вже відкриті вкладки Gartic Phone
async function inject() {
  const tabs = await chrome.tabs.query({ url: ['https://garticphone.com/*', 'https://*.garticphone.com/*'] });
  for (const tab of tabs) {
    try { await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] }); }
    catch (e) { console.warn('inject failed', e); }
  }
}
chrome.runtime.onInstalled.addListener(inject);
chrome.runtime.onStartup.addListener(inject);

// 2) Справжні події миші через Chrome Debugger API
const attached = new Set();
chrome.debugger.onDetach.addListener((src) => attached.delete(src.tabId));

async function ensure(tabId) {
  if (attached.has(tabId)) return;
  try {
    await chrome.debugger.attach({ tabId }, '1.3');
  } catch (e) {
    if (!/already attached/i.test(String(e && e.message || e))) throw e;
  }
  attached.add(tabId);
}
const mouse = (tabId, type, x, y, buttons) =>
  chrome.debugger.sendCommand({ tabId }, 'Input.dispatchMouseEvent', {
    type, x, y, button: type === 'mouseMoved' && !buttons ? 'none' : 'left',
    buttons, clickCount: type === 'mouseMoved' ? 0 : 1
  });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  const tabId = sender.tab && sender.tab.id;
  if (tabId == null) return;

  if (msg.type === 'draw') {
    (async () => {
      try {
        await ensure(tabId);
        const delay = msg.delay || 0;
        for (const p of msg.strokes) {            // p = [x0,y0,x1,y1,...]
          await mouse(tabId, 'mouseMoved', p[0], p[1], 0);
          await mouse(tabId, 'mousePressed', p[0], p[1], 1);
          let px = p[0], py = p[1];
          for (let i = 2; i < p.length; i += 2) {
            const x = p[i], y = p[i + 1];
            const steps = Math.max(1, Math.ceil(Math.hypot(x - px, y - py) / 30));
            for (let k = 1; k <= steps; k++) {
              await mouse(tabId, 'mouseMoved', px + ((x - px) * k) / steps, py + ((y - py) * k) / steps, 1);
            }
            px = x; py = y;
          }
          if (p.length <= 4 && p[0] === p[2] && p[1] === p[3]) await mouse(tabId, 'mouseMoved', px + 0.5, py + 0.5, 1);
          await mouse(tabId, 'mouseReleased', px, py, 0);
          if (delay) await sleep(delay);
        }
        reply({ ok: true });
      } catch (e) {
        reply({ ok: false, error: String(e && e.message || e) });
      }
    })();
    return true;
  }

  if (msg.type === 'click') {
    (async () => {
      try {
        await ensure(tabId);
        await mouse(tabId, 'mouseMoved', msg.x, msg.y, 0);
        await mouse(tabId, 'mousePressed', msg.x, msg.y, 1);
        await sleep(40);
        await mouse(tabId, 'mouseReleased', msg.x, msg.y, 0);
        await sleep(120);
        reply({ ok: true });
      } catch (e) {
        reply({ ok: false, error: String(e && e.message || e) });
      }
    })();
    return true;
  }

  if (msg.type === 'end') {
    if (attached.has(tabId)) {
      chrome.debugger.detach({ tabId }).catch(() => {});
      attached.delete(tabId);
    }
  }
});

// 3) Завантаження картинки за посиланням (GitHub тощо) в обхід CORS сторінки
function normalizeUrl(u) {
  u = u.trim();
  let m = u.match(/^https?:\/\/github\.com\/([^/]+)\/([^/]+)\/(?:blob|raw)\/(.+?)(?:[?#].*)?$/i);
  if (m) return `https://raw.githubusercontent.com/${m[1]}/${m[2]}/${m[3]}`;
  return u;
}
function toBase64(buf) {
  const bytes = new Uint8Array(buf);
  let s = '';
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(s);
}
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg.type !== 'fetchImage') return;
  (async () => {
    try {
      const url = normalizeUrl(msg.url);
      if (!/^https:\/\//i.test(url)) throw new Error('Потрібне посилання https://');
      const r = await fetch(url);
      if (!r.ok) throw new Error('HTTP ' + r.status);
      let type = (r.headers.get('content-type') || '').split(';')[0].trim();
      const buf = await r.arrayBuffer();
      if (!type.startsWith('image/')) {
        if (/\.svg(\?|$)/i.test(url)) type = 'image/svg+xml';
        else if (/\.(png|jpe?g|gif|webp|bmp)(\?|$)/i.test(url)) type = 'image/' + url.match(/\.(png|jpe?g|gif|webp|bmp)/i)[1].toLowerCase().replace('jpg', 'jpeg');
        else throw new Error('Це не картинка. Встав посилання на файл-зображення (blob/raw).');
      }
      reply({ ok: true, dataUrl: `data:${type};base64,${toBase64(buf)}` });
    } catch (e) {
      reply({ ok: false, error: String(e && e.message || e) });
    }
  })();
  return true;
});
