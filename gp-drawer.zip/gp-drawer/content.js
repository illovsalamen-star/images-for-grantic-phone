(() => {
  const old = document.getElementById('gpd-panel');
  if (old) old.remove();

  // ---------- UI ----------
  const panel = document.createElement('div');
  panel.id = 'gpd-panel';
  panel.style.cssText = `position:fixed;top:60px;left:10px;z-index:2147483647;width:230px;
    background:#1b1b2f;color:#fff;font:13px/1.4 Arial,sans-serif;border-radius:10px;
    box-shadow:0 4px 20px rgba(0,0,0,.5);overflow:hidden`;
  panel.innerHTML = `
    <div id="gpd-head" style="cursor:move;background:#5b3cc4;padding:8px 10px;font-weight:bold;display:flex;justify-content:space-between">
      <span>🎨 Auto Drawer</span><span id="gpd-min" style="cursor:pointer">—</span>
    </div>
    <div id="gpd-body" style="padding:10px;display:flex;flex-direction:column;gap:8px">
      <input type="file" id="gpd-file" accept="image/*" style="font-size:12px">
      <div style="display:flex;gap:4px">
        <input type="text" id="gpd-url" placeholder="Встав посилання (GitHub)…" style="flex:1;min-width:0;padding:4px;font-size:12px">
        <button id="gpd-load" style="padding:4px 6px;cursor:pointer">⬇</button>
      </div>
      <label>Режим
        <select id="gpd-mode" style="width:100%">
          <option value="color">Кольорове (авто-палітра)</option>
          <option value="edges">Контури</option>
          <option value="shade">Темні ділянки (заливка)</option>
        </select>
      </label>
      <label>Деталізація: <span id="gpd-dv">70</span>
        <input type="range" id="gpd-detail" min="30" max="300" value="70" style="width:100%">
      </label>
      <label>Поріг: <span id="gpd-tv">60</span>
        <input type="range" id="gpd-thr" min="5" max="250" value="60" style="width:100%">
      </label>
      <label>Об'єднання ліній: <span id="gpd-jv">6</span>
        <input type="range" id="gpd-join" min="0" max="20" value="6" style="width:100%">
      </label>
      <label>Швидкість: <span id="gpd-sv">4</span>
        <input type="range" id="gpd-speed" min="1" max="40" value="4" style="width:100%">
      </label>
      <label style="display:flex;gap:6px;align-items:center"><input type="checkbox" id="gpd-dbg" checked> Надійний режим (справжня миша)</label>
      <div style="display:flex;gap:6px">
        <button id="gpd-go" style="flex:1;padding:6px;cursor:pointer">▶ Малювати</button>
        <button id="gpd-stop" style="flex:1;padding:6px;cursor:pointer">■ Стоп</button>
      </div>
      <button id="gpd-cal" style="padding:6px;cursor:pointer">🎯 Калібрувати (1 лінія)</button>
      <button id="gpd-pal" style="padding:6px;cursor:pointer">🎨 Палітра вручну</button>
      <div id="gpd-status" style="font-size:12px;color:#bbb">Обери фото</div>
      <div style="font-size:11px;color:#888">У кольоровому режимі колір міняється сам; обери товщий пензель, щоб не було пробілів.</div>
    </div>`;
  document.body.appendChild(panel);

  const $ = (id) => panel.querySelector('#' + id);
  const status = (t) => ($('gpd-status').textContent = t);
  [['gpd-join', 'gpd-jv'], ['gpd-detail', 'gpd-dv'], ['gpd-thr', 'gpd-tv'], ['gpd-speed', 'gpd-sv']].forEach(([a, b]) =>
    $(a).addEventListener('input', () => ($(b).textContent = $(a).value)));

  $('gpd-min').onclick = () => {
    const b = $('gpd-body');
    b.style.display = b.style.display === 'none' ? 'flex' : 'none';
  };

  // drag panel
  let drag = null;
  $('gpd-head').addEventListener('mousedown', (e) => {
    drag = { x: e.clientX - panel.offsetLeft, y: e.clientY - panel.offsetTop };
  });
  window.addEventListener('mousemove', (e) => {
    if (!drag) return;
    panel.style.left = e.clientX - drag.x + 'px';
    panel.style.top = e.clientY - drag.y + 'px';
  });
  window.addEventListener('mouseup', () => (drag = null));

  // ---------- Image loading ----------
  let img = null;
  $('gpd-file').addEventListener('change', (e) => {
    const f = e.target.files[0];
    if (!f) return;
    const im = new Image();
    im.onload = () => { img = im; status('Фото завантажено ✔'); };
    im.src = URL.createObjectURL(f);
  });

  // ---------- Load from URL (GitHub etc.) ----------
  async function loadUrl() {
    const url = $('gpd-url').value.trim();
    if (!url) return status('Встав посилання!');
    status('Завантажую…');
    let res;
    try { res = await chrome.runtime.sendMessage({ type: 'fetchImage', url }); }
    catch (e) { res = { ok: false, error: 'Онови розширення і сторінку (F5). ' + e }; }
    if (!res || !res.ok) return status('Помилка: ' + ((res && res.error) || 'немає відповіді'));
    const im = new Image();
    im.onload = () => { img = im; status('Фото з посилання завантажено ✔'); };
    im.onerror = () => status('Не вдалося прочитати зображення');
    im.src = res.dataUrl;
  }
  $('gpd-load').onclick = loadUrl;
  $('gpd-url').addEventListener('keydown', (e) => { if (e.key === 'Enter') loadUrl(); e.stopPropagation(); });
  $('gpd-url').addEventListener('keyup', (e) => e.stopPropagation());
  $('gpd-url').addEventListener('paste', () => setTimeout(loadUrl, 50));

  // ---------- Canvas finding ----------
  function findCanvas() {
    let best = null, area = 0;
    document.querySelectorAll('canvas').forEach((c) => {
      const r = c.getBoundingClientRect();
      const a = r.width * r.height;
      if (r.width > 200 && r.height > 150 && a > area) { best = c; area = a; }
    });
    return best;
  }

  // ---------- Calibration ----------
  let calib = null; // { target, types[] }
  $('gpd-cal').onclick = () => {
    status('Намалюй у грі ОДНУ коротку лінію мишею…');
    const all = ['pointerdown', 'mousedown', 'pointermove', 'mousemove',
                 'pointerup', 'mouseup', 'touchstart', 'touchmove', 'touchend'];
    const seen = [];
    let target = null, timer = null;
    const h = (e) => {
      if (panel.contains(e.target)) return;
      if (!target && /down|start/.test(e.type)) target = e.target;
      if (!target) return;
      if (!seen.includes(e.type)) seen.push(e.type);
      if (/up$|end$/.test(e.type) && !timer) {
        timer = setTimeout(() => {
          all.forEach((t) => window.removeEventListener(t, h, true));
          calib = { target, types: seen.slice() };
          status('Калібрування ✔ ' + target.tagName + ' [' + seen.join(', ') + ']');
        }, 200);
      }
    };
    all.forEach((t) => window.addEventListener(t, h, true));
  };

  // ---------- Event dispatch ----------
  function fire(el, type, x, y, down) {
    const base = {
      bubbles: true, cancelable: true, composed: true, view: window,
      clientX: x, clientY: y, screenX: x, screenY: y,
      button: 0, buttons: down ? 1 : 0
    };
    if (type.startsWith('pointer')) {
      el.dispatchEvent(new PointerEvent(type, {
        ...base, pointerId: 1, pointerType: 'mouse', isPrimary: true,
        width: 1, height: 1, pressure: down ? 0.5 : 0
      }));
    } else if (type.startsWith('mouse')) {
      el.dispatchEvent(new MouseEvent(type, base));
    }
  }
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // ---------- mask -> runs ----------
  function runs(mask, w, h) {
    const strokes = []; // in grid coords: [x0,y0,x1,y1]
    const covered = new Uint8Array(w * h);
    // horizontal runs
    for (let y = 0; y < h; y++) {
      let x = 0;
      while (x < w) {
        if (mask[y * w + x]) {
          let x1 = x;
          while (x1 + 1 < w && mask[y * w + x1 + 1]) x1++;
          if (x1 > x) {
            strokes.push([x, y, x1, y]);
            for (let k = x; k <= x1; k++) covered[y * w + k] = 1;
          }
          x = x1 + 1;
        } else x++;
      }
    }
    // vertical runs for the rest
    for (let x = 0; x < w; x++) {
      let y = 0;
      while (y < h) {
        if (mask[y * w + x] && !covered[y * w + x]) {
          let y1 = y;
          while (y1 + 1 < h && mask[(y1 + 1) * w + x] && !covered[(y1 + 1) * w + x]) y1++;
          strokes.push([x, y, x, y1]); // single pixel = dot
          y = y1 + 1;
        } else y++;
      }
    }
    return strokes;
  }

  // ---------- Image -> strokes ----------
  function buildStrokes(mode, detail, thr) {
    const w = detail;
    const h = Math.max(1, Math.round((detail * img.height) / img.width));
    const off = document.createElement('canvas');
    off.width = w; off.height = h;
    const ctx = off.getContext('2d', { willReadFrequently: true });
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, w, h);
    ctx.drawImage(img, 0, 0, w, h);
    const d = ctx.getImageData(0, 0, w, h).data;

    const g = new Float32Array(w * h);
    for (let i = 0; i < w * h; i++) {
      g[i] = 0.299 * d[i * 4] + 0.587 * d[i * 4 + 1] + 0.114 * d[i * 4 + 2];
    }

    const mask = new Uint8Array(w * h);
    if (mode === 'shade') {
      for (let i = 0; i < w * h; i++) mask[i] = g[i] < thr ? 1 : 0;
    } else {
      // Sobel
      for (let y = 1; y < h - 1; y++) {
        for (let x = 1; x < w - 1; x++) {
          const i = y * w + x;
          const gx = -g[i - w - 1] - 2 * g[i - 1] - g[i + w - 1] + g[i - w + 1] + 2 * g[i + 1] + g[i + w + 1];
          const gy = -g[i - w - 1] - 2 * g[i - w] - g[i - w + 1] + g[i + w - 1] + 2 * g[i + w] + g[i + w + 1];
          mask[i] = Math.hypot(gx, gy) > thr * 3 ? 1 : 0;
        }
      }
    }

    const strokes = runs(mask, w, h);
    return { strokes, w, h };
  }

  // ---------- Chain strokes into long polylines ----------
  function chain(strokes, J) {
    if (J <= 0) return strokes.map((s) => [[s[0], s[1]], [s[2], s[3]]]);
    const map = new Map();
    const K = (x, y) => y * 100000 + x;
    strokes.forEach((s, i) => {
      [0, 1].forEach((e) => {
        const k = K(e ? s[2] : s[0], e ? s[3] : s[1]);
        if (!map.has(k)) map.set(k, []);
        map.get(k).push([i, e]);
      });
    });
    const used = new Uint8Array(strokes.length);
    const out = [];
    for (let i = 0; i < strokes.length; i++) {
      if (used[i]) continue;
      used[i] = 1;
      const path = [[strokes[i][0], strokes[i][1]], [strokes[i][2], strokes[i][3]]];
      let cx = strokes[i][2], cy = strokes[i][3];
      for (;;) {
        let best = null, bd = 1e9;
        for (let dy = -J; dy <= J; dy++) {
          for (let dx = -J; dx <= J; dx++) {
            const list = map.get(K(cx + dx, cy + dy));
            if (!list) continue;
            const d = dx * dx + dy * dy;
            if (d >= bd) continue;
            for (const it of list) if (!used[it[0]]) { best = it; bd = d; break; }
          }
        }
        if (!best) break;
        const [id, e] = best;
        used[id] = 1;
        const t = strokes[id];
        const a = e ? [t[2], t[3]] : [t[0], t[1]];
        const b = e ? [t[0], t[1]] : [t[2], t[3]];
        path.push(a, b);
        cx = b[0]; cy = b[1];
      }
      out.push(path);
    }
    return out;
  }

  // ---------- Palette ----------
  const parseRGB = (s) => {
    const m = String(s).match(/rgba?\(\s*(\d+)[ ,]+(\d+)[ ,]+(\d+)(?:[ ,/]+([\d.]+%?))?/);
    if (!m) return null;
    let a = m[4] === undefined ? 1 : (m[4].endsWith('%') ? parseFloat(m[4]) / 100 : parseFloat(m[4]));
    return { rgb: [+m[1], +m[2], +m[3]], a };
  };
  function colorOf(el) {
    for (let e = el, i = 0; e && i < 4; e = e.parentElement, i++) {
      const p = parseRGB(getComputedStyle(e).backgroundColor);
      if (p && p.a > 0.9) return { el: e, rgb: p.rgb };
    }
    return null;
  }
  let manualPal = [];
  function detectSwatches() {
    const cv = findCanvas();
    const cr = cv ? cv.getBoundingClientRect() : null;
    const found = [];
    document.querySelectorAll('body *').forEach((el) => {
      if (panel.contains(el) || el === cv) return;
      const r = el.getBoundingClientRect();
      if (r.width < 14 || r.width > 70 || r.height < 14 || r.height > 70) return;
      const ratio = r.width / r.height;
      if (ratio < 0.6 || ratio > 1.6) return;
      if (r.bottom < 0 || r.top > innerHeight || r.right < 0 || r.left > innerWidth) return;
      if (cr && r.left >= cr.left && r.right <= cr.right && r.top >= cr.top && r.bottom <= cr.bottom) return;
      const p = parseRGB(getComputedStyle(el).backgroundColor);
      if (!p || p.a < 0.9) return;
      found.push({ el, rgb: p.rgb, key: Math.round(r.width / 3) + 'x' + Math.round(r.height / 3), cx: r.left + r.width / 2, cy: r.top + r.height / 2 });
    });
    const groups = new Map();
    found.forEach((f) => { if (!groups.has(f.key)) groups.set(f.key, []); groups.get(f.key).push(f); });
    let best = [];
    groups.forEach((g) => { if (g.length > best.length) best = g; });
    const out = [];
    best.forEach((f) => {
      if (!out.some((o) => Math.hypot(o.cx - f.cx, o.cy - f.cy) < 4)) out.push(f);
    });
    return out;
  }
  function getPalette() {
    manualPal = manualPal.filter((m) => m.el.isConnected);
    return manualPal.length >= 2 ? manualPal : detectSwatches();
  }

  let palCap = null;
  $('gpd-pal').onclick = () => {
    if (palCap) {
      window.removeEventListener('click', palCap, true);
      palCap = null;
      $('gpd-pal').textContent = '🎨 Палітра вручну';
      status('Палітра: ' + manualPal.length + ' кольорів ✔');
      return;
    }
    manualPal = [];
    $('gpd-pal').textContent = '✔ Готово (клікай по кольорах у грі)';
    status('Клікни в грі по КОЖНОМУ кольору палітри, потім натисни «Готово»');
    palCap = (e) => {
      if (panel.contains(e.target)) return;
      const c = colorOf(e.target);
      if (!c) return;
      const r = c.el.getBoundingClientRect();
      if (manualPal.some((m) => m.el === c.el)) return;
      manualPal.push({ el: c.el, rgb: c.rgb, cx: r.left + r.width / 2, cy: r.top + r.height / 2 });
      status('Кольорів: ' + manualPal.length);
    };
    window.addEventListener('click', palCap, true);
  };

  // ---------- Color quantization ----------
  function cdist(a, b) {
    const rm = (a[0] + b[0]) / 2, dr = a[0] - b[0], dg = a[1] - b[1], db = a[2] - b[2];
    return (2 + rm / 256) * dr * dr + 4 * dg * dg + (2 + (255 - rm) / 256) * db * db;
  }
  function buildColor(detail, pal) {
    const w = detail;
    const h = Math.max(1, Math.round((detail * img.height) / img.width));
    const off = document.createElement('canvas');
    off.width = w; off.height = h;
    const ctx = off.getContext('2d', { willReadFrequently: true });
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, w, h);
    ctx.drawImage(img, 0, 0, w, h);
    const d = ctx.getImageData(0, 0, w, h).data;
    const masks = pal.map(() => new Uint8Array(w * h));
    const counts = pal.map(() => 0);
    for (let i = 0; i < w * h; i++) {
      const px = [d[i * 4], d[i * 4 + 1], d[i * 4 + 2]];
      if (px[0] > 235 && px[1] > 235 && px[2] > 235) continue; // біле = фон полотна
      let bi = 0, bd = Infinity;
      for (let k = 0; k < pal.length; k++) {
        const dd = cdist(px, pal[k].rgb);
        if (dd < bd) { bd = dd; bi = k; }
      }
      masks[bi][i] = 1; counts[bi]++;
    }
    const layers = [];
    pal.forEach((sw, k) => {
      if (!counts[k]) return;
      const strokes = runs(masks[k], w, h);
      if (strokes.length) {
        strokes.sort((a, b) => a[1] - b[1] || a[0] - b[0]);
        layers.push({ sw, strokes, n: counts[k] });
      }
    });
    layers.sort((a, b) => b.n - a.n);
    return { layers, w, h };
  }

  async function drawColor(canvas) {
    const pal = getPalette();
    if (pal.length < 2) return status('Палітру не знайдено. Натисни «🎨 Палітра вручну» і клікни по кольорах у грі.');
    const { layers, w, h } = buildColor(+$('gpd-detail').value, pal);
    if (!layers.length) return status('Нічого малювати.');
    const r = canvas.getBoundingClientRect();
    const cell = Math.min(r.width / w, r.height / h);
    const ox = r.left + (r.width - cell * w) / 2;
    const oy = r.top + (r.height - cell * h) / 2;
    const P = (gx, gy) => [ox + (gx + 0.5) * cell, oy + (gy + 0.5) * cell];
    status('Кольорів у палітрі: ' + pal.length + ', використано: ' + layers.length);
    await sleep(800);
    running = true;
    panel.style.opacity = '0.5';
    panel.style.pointerEvents = 'none';
    $('gpd-stop').style.pointerEvents = 'auto';
    const speedVal = +$('gpd-speed').value;
    const CH = 5;
    for (let li = 0; li < layers.length && running; li++) {
      const L = layers[li];
      const sr = L.sw.el.isConnected ? L.sw.el.getBoundingClientRect() : null;
      const sx = sr ? sr.left + sr.width / 2 : L.sw.cx, sy = sr ? sr.top + sr.height / 2 : L.sw.cy;
      let res;
      try { res = await chrome.runtime.sendMessage({ type: 'click', x: sx, y: sy }); }
      catch (e) { res = { ok: false, error: String(e) }; }
      if (!res || !res.ok) { status('Помилка: ' + ((res && res.error) || 'онови розширення')); stopAll(); return; }
      const paths = chain(L.strokes, +$('gpd-join').value);
      const pts = paths.map((p) => {
        const flat = [];
        p.forEach(([gx, gy]) => { const [x, y] = P(gx, gy); flat.push(+x.toFixed(1), +y.toFixed(1)); });
        return flat;
      });
      for (let i = 0; i < pts.length && running; i += CH) {
        status(`Колір ${li + 1}/${layers.length}: ${i}/${pts.length} (Esc — стоп)`);
        try {
          res = await chrome.runtime.sendMessage({ type: 'draw', delay: Math.max(0, Math.round(60 - speedVal * 1.4)), strokes: pts.slice(i, i + CH) });
        } catch (e) { res = { ok: false, error: String(e) }; }
        if (!res || !res.ok) { status('Помилка: ' + ((res && res.error) || 'немає відповіді')); stopAll(); return; }
      }
    }
    const was = running;
    stopAll();
    status(was ? 'Готово ✔' : 'Зупинено');
  }

  // ---------- Drawing ----------
  let running = false;
  const stopAll = () => {
    running = false;
    panel.style.pointerEvents = '';
    panel.style.opacity = '';
    try { chrome.runtime.sendMessage({ type: 'end' }); } catch (e) {}
  };
  $('gpd-stop').onclick = () => { stopAll(); status('Зупинено'); };
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && running) { stopAll(); status('Зупинено (Esc)'); }
  });

  $('gpd-go').onclick = async () => {
    if (running) return;
    if (!img) return status('Спочатку обери фото!');
    const canvas = (calib && calib.target.isConnected && calib.target instanceof HTMLCanvasElement)
      ? calib.target : findCanvas();
    if (!canvas) return status('Полотно не знайдено. Зайди в раунд малювання.');

    if ($('gpd-mode').value === 'color') return drawColor(canvas);

    const mode = $('gpd-mode').value;
    const { strokes, w, h } = buildStrokes(mode, +$('gpd-detail').value, +$('gpd-thr').value);
    if (!strokes.length) return status('Нічого малювати — зміни поріг.');

    const r = canvas.getBoundingClientRect();
    const cell = Math.min(r.width / w, r.height / h);
    const ox = r.left + (r.width - cell * w) / 2;
    const oy = r.top + (r.height - cell * h) / 2;
    const P = (gx, gy) => [ox + (gx + 0.5) * cell, oy + (gy + 0.5) * cell];
    strokes.sort((a, b) => a[1] - b[1] || a[0] - b[0]);

    status('Штрихів: ' + strokes.length + ' — для швидкості зменши деталізацію');
    await sleep(600);
    running = true;
    // панель не повинна перекривати полотно під час малювання
    panel.style.opacity = '0.5';
    panel.style.pointerEvents = 'none';
    $('gpd-stop').style.pointerEvents = 'auto';

    if ($('gpd-dbg').checked) {
      // ----- Надійний режим: справжні події миші через chrome.debugger -----
      const paths = chain(strokes, +$('gpd-join').value);
      const pts = paths.map((p) => {
        const flat = [];
        p.forEach(([gx, gy]) => { const [x, y] = P(gx, gy); flat.push(+x.toFixed(1), +y.toFixed(1)); });
        return flat;
      });
      status('Ліній: ' + pts.length + ' (було ' + strokes.length + ')');
      await sleep(800);
      const CH = 5;
      const speedVal = +$('gpd-speed').value;
      for (let i = 0; i < pts.length && running; i += CH) {
        status(`Малюю: ${i}/${pts.length} (Esc — стоп)`);
        let res;
        try {
          res = await chrome.runtime.sendMessage({ type: 'draw', delay: Math.max(0, Math.round(60 - speedVal * 1.4)), strokes: pts.slice(i, i + CH) });
        } catch (e) { res = { ok: false, error: String(e) }; }
        if (!res || !res.ok) {
          status('Помилка: ' + ((res && res.error) || 'немає відповіді. Онови розширення.'));
          stopAll();
          return;
        }
      }
      const was = running;
      stopAll();
      status(was ? 'Готово ✔' : 'Зупинено');
      return;
    }

    // ----- Простий режим: синтетичні події -----
    const cr = r;
    const target = calib && calib.target.isConnected ? calib.target
      : (document.elementFromPoint(cr.left + cr.width / 2, cr.top + cr.height / 2) || canvas);
    const types = calib
      ? calib.types.filter((t) => /^(pointer|mouse)/.test(t))
      : ['pointerdown', 'mousedown', 'pointermove', 'mousemove', 'pointerup', 'mouseup'];
    const ev = (t, x, y, d) => { if (types.includes(t)) fire(target, t, x, y, d); };
    const batch = +$('gpd-speed').value;
    for (let i = 0; i < strokes.length && running; i++) {
      const [x0, y0, x1, y1] = strokes[i];
      const [sx, sy] = P(x0, y0), [ex, ey] = P(x1, y1);
      ev('pointerdown', sx, sy, true); ev('mousedown', sx, sy, true);
      const steps = Math.max(1, Math.ceil(Math.hypot(ex - sx, ey - sy) / 6));
      for (let k = 1; k <= steps; k++) {
        const x = sx + ((ex - sx) * k) / steps, y = sy + ((ey - sy) * k) / steps;
        ev('pointermove', x, y, true); ev('mousemove', x, y, true);
      }
      ev('pointerup', ex, ey, false); ev('mouseup', ex, ey, false);
      if (i % batch === 0) { status(`Малюю: ${i}/${strokes.length}`); await sleep(4); }
    }
    const was = running;
    stopAll();
    status(was ? 'Готово ✔' : 'Зупинено');
  };
})();
